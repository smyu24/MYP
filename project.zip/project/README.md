# Sleep Monitor
#### Video Demo:  <URL HERE>
#### Description:
My final project will be about Sleep and the importance of tracking it to get the healthiest time
--------------------------------------------------------------------------------------------------
Done:
    Register (Register User and gathers info such as username, password, email. Has additional features like hyperlinks to register, login)
    Login (Logs user into their account. Has additional features like hyperlinks to register, login, recover acc.)
    Rate (Users of the website can rate the website using a combination of comments and stars)
    Layout (Basic landscape of the website. Everypage will use it's template)
    Links (Filled with helpful links and advice)
    Settings (Need to get the update password working. Also try to get unhashed password)

Working on:
    Index ("Main" page of the website that the user will first encounter when they login)
    Quote/Quoted (Needs to )

Not Done:
    Compare (Needs to portray data in the form of a graph in order for the user to compare their sleep data to other's if they wish to)